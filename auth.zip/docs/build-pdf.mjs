// Renders docs/qa-automation-guide.html to docs/QA-Automation-Guide.pdf with Playwright's Chromium.
// Usage: npm run docs:pdf
import { chromium } from '@playwright/test';
import path from 'node:path';
import { pathToFileURL } from 'node:url';

const source = path.resolve('docs/qa-automation-guide.html');
const output = path.resolve('docs/QA-Automation-Guide.pdf');

const footer = `
  <div style="font-family:'Segoe UI',Arial,sans-serif;font-size:7.5pt;color:#5b6676;width:100%;padding:0 16mm;display:flex;justify-content:space-between;">
    <span>QA Automation Framework · Module Testing &amp; Automation Guide</span>
    <span>Page <span class="pageNumber"></span> of <span class="totalPages"></span></span>
  </div>`;

const browser = await chromium.launch();
const page = await browser.newPage();
await page.goto(pathToFileURL(source).href, { waitUntil: 'load' });
await page.pdf({
  path: output,
  format: 'A4',
  printBackground: true,
  displayHeaderFooter: true,
  headerTemplate: '<div></div>',
  footerTemplate: footer,
  margin: { top: '16mm', bottom: '18mm', left: '16mm', right: '16mm' },
});
await browser.close();
console.log(`PDF written to ${output}`);
