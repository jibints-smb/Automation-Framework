# QA Automation Framework (Playwright + Appium + Claude MCP)

Company-wide test automation for web and mobile apps. One shared framework (`src/`), one folder per
application (`apps/<app>/`). Requirements (Jira stories, developer module notes) arrive as Markdown; we turn
them into test cases and then into automated tests. Reports are Allure.

## Active app
`APP` in the root `.env` (or `APP=<name>` on the command line) selects the app. Its settings are in
`apps/<app>/app.config.ts` (platforms, base URL, test-id attribute, login roles) and `apps/<app>/.env`.
Always check which app you are working on before creating files.

## Workflow (per module)
1. `apps/<app>/requirements/<JIRA>-<module>.md`: story or dev notes (template: `templates/requirement.md`)
2. `/qa-testcases <requirement.md>` → `apps/<app>/test-cases/<module>.testcases.md` (QA reviews it)
3. `/qa-automate <testcases.md>` → model + page/screen + data + spec, run until green
4. `/qa-fix [spec|@tag]` → triage failures: automation issue vs. real bug
5. `npm run coverage:tc` → which test-case IDs are not automated yet
6. Developer changes a module MD later (bug-fix iteration) → `npm run req:status` flags it CHANGED,
   `npm run req:diff -- <md>` shows what changed, `/qa-update <md>` updates only the affected tests.

## Requirement baselines
`apps/<app>/requirements/.baseline/` stores the version of each MD that QA last processed (stage:
`cases` → `automated` → `signed-off`). Commands record `cases`/`automated` themselves; only QA records
`signed-off` (`npm run req:baseline -- <md> --stage signed-off --by "<name>"`). Never edit baseline files by
hand, never renumber test-case IDs (retire removed ones with `Automate: no`).

## Layout
```
src/                 SHARED FRAMEWORK: generic only, never app-specific code
  config/            env.ts (only place reading process.env), app.ts (defineApp, settings), paths.ts
  models/            field.types.ts: Field, WebLocator, MobileLocator, FormData, defineWebFields
  web/               BasePage, WebActions (act), WebAssertions (verify), locator resolver
  mobile/            BaseScreen, MobileActions, MobileAssertions, Appium driver + capabilities
  api/               ApiClient (REST for setup/cleanup)
  auth/              auth.setup.ts: logs in every role from app.config.ts
  fixtures/          core `test`: role, platform, api, cleanup, driver, `report` (auto)
  report/            Allure enrichment: test case per test, failure cause + bug report attachment
  utils/             step(), storyInfo() / knownBug() (Allure), cleanup, random data
apps/<app>/          ONE APPLICATION
  app.config.ts      platforms, web base URL, test-id attribute, auth roles + login steps
  fixtures.ts        extends core test with this app's pages/screens; specs import test from here
  models/web|mobile  field models          pages/  screens/   page & screen objects
  data/              typed test data       tests/web|mobile   specs
  requirements/      module MD files       test-cases/        reviewed test cases
templates/           requirement.md, testcases.md
scripts/             new-app.mjs, tc-coverage.mjs
```
Imports: `@core/...` for the framework, `@apps/<app>/...` for app code.

## Rules
- Specs import `test`/`expect` from `@apps/<app>/fixtures`, never from `@playwright/test`.
- **Locators live only in models.** Pages/screens use `this.act.*` and `this.verify.*` with model fields.
  Dynamic locators are functions in the model returning a `WebField`/`MobileField`.
- Locator preference (web): `testId` → `role`+`name` → `label` → `placeholder` → `text` → `css`; avoid `xpath`.
  Mobile: `accessibilityId` → `id` → `text` → platform-specific selectors.
- UI components: dropdowns (native or custom), dates, radios and iframe fields are handled by `act.setValue`/`fillForm`
  from the field `type`. Custom dropdowns whose options aren't `role="option"` set `option: (v) => locator`;
  fields inside an iframe set `frame: '<iframe css>'`.
- Data types come from models: `type XData = FormData<typeof XFields>`; don't hand-write data interfaces.
- Specs read like test cases: one test per test-case ID, title `<ID> | <Title>`,
  tags `@smoke`/`@regression` + `@<ID>`, `storyInfo({...})` in `beforeEach`.
- The report finds each test's test case by the ID in its title, so keep titles `<ID> | <Title>` and test-case
  Priority/Expected result accurate. Every action/check goes through `step()` (act/verify do), so the bug
  report can list it. A confirmed app bug: `knownBug('<JIRA-KEY>', '<summary>')` as the first line of the test,
  never a weakened assertion.
- No `waitForTimeout`/sleeps; use web-first assertions (`verify.*`) and auto-waiting actions.
- Tests start logged in as the app's default role. `test.use({ role: 'admin' })` for another role,
  `test.use({ role: null })` for logged out.
- Create test data through `api` and register removal with `cleanup.add(...)`; test error/empty states with `act.mockApi(...)`.
- App-specific settings: `getEnv('NAME')` / `requireEnv('NAME')` from `@core/config/env`.
- Anything app-specific goes in `apps/<app>/`; change `src/` only for generic features every app benefits from.
- Never print or commit secrets from `.env` files (they hold QA test accounts only).

## Commands
- `npx tsc --noEmit`: type check (run after every change)
- `npx playwright test <file> --project=web-chrome`: run one spec
- `npm run test:web` · `test:mobile-web` · `test:android` · `test:ios` · `test:smoke` · `test:regression`
- `npm run auth`: refresh saved logins · `npm run coverage:tc`: test-case coverage
- `npm run req:status` · `npm run req:diff -- <md>` · `npm run req:baseline -- <md> --stage <cases|automated|signed-off>`
- `npm run new:app -- <name> --platforms web,android`: new application
- `npm run report`: build and open the Allure report
- Don't pass `--reporter` on the CLI: it replaces the configured Allure reporter.
