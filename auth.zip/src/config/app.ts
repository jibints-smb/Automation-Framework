/**
 * Per-application configuration. Every app has `apps/<name>/app.config.ts`:
 *
 *   export default defineApp({ name: 'Shop', platforms: ['web'], web: { baseUrl: 'https://qa.shop.com' } });
 *
 * The active app (APP setting) is loaded here and exposed as `app` and `settings`.
 */
import path from 'node:path';
import type { Page } from '@playwright/test';
import { APP_DIR, env } from './env';

export type PlatformName = 'web' | 'mobile-web' | 'android' | 'ios';

export interface RoleAccount {
  /** Name of the setting holding the username, e.g. 'ADMIN_USERNAME'. */
  usernameEnv: string;
  /** Name of the setting holding the password, e.g. 'ADMIN_PASSWORD'. */
  passwordEnv: string;
}

export interface AppConfig {
  /** Display name, used in the report. */
  name: string;
  /** Which kinds of test runs this app has. Decides the Playwright projects. */
  platforms: PlatformName[];

  web?: {
    baseUrl: string;
    /** Attribute developers use for test IDs. Default: data-testid */
    testIdAttribute?: string;
  };

  api?: {
    /** Defaults to web.baseUrl. */
    baseUrl?: string;
    headers?: Record<string, string>;
  };

  /**
   * Web login, done once per role before the tests; each test then starts logged in.
   * Leave out for apps without login.
   */
  auth?: {
    defaultRole: string;
    roles: Record<string, RoleAccount>;
    /** Log in on a fresh page and wait until logged in. */
    login: (page: Page, credentials: { username: string; password: string }) => Promise<void>;
  };
}

export function defineApp(config: AppConfig): AppConfig {
  return config;
}

export const app: AppConfig = require(path.join(APP_DIR, 'app.config.ts')).default;

/** Final values: environment settings override the app's defaults. */
export const settings = {
  baseUrl: env.web.baseUrl || app.web?.baseUrl || '',
  testIdAttribute: env.web.testIdAttribute || app.web?.testIdAttribute || 'data-testid',
  apiBaseUrl: env.api.baseUrl || app.api?.baseUrl || env.web.baseUrl || app.web?.baseUrl || '',
  apiHeaders: {
    ...app.api?.headers,
    ...(env.api.token ? { Authorization: `Bearer ${env.api.token}` } : {}),
  },
} as const;
