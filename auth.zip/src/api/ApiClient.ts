import type { APIRequestContext } from '@playwright/test';
import { step } from '@core/utils/step';

export interface ApiRequestOptions {
  /** JSON body (objects are sent as JSON). */
  data?: unknown;
  /** Query string parameters. */
  params?: Record<string, string | number | boolean>;
  headers?: Record<string, string>;
  /** Expected status. Default: any 2xx; anything else fails the step with the response body. */
  expectStatus?: number;
}

export interface ApiResponse<T> {
  status: number;
  headers: Record<string, string>;
  body: T;
}

/**
 * Small REST client for test setup, cleanup and API checks.
 * Base URL and auth headers come from the app config / .env (API_BASE_URL, API_TOKEN).
 *
 * @example
 *   const { body } = await api.post<{ id: string }>('/api/v1/customers', { data: customer });
 *   cleanup.add(`Delete customer ${body.id}`, () => api.delete(`/api/v1/customers/${body.id}`));
 */
export class ApiClient {
  constructor(private readonly request: APIRequestContext) {}

  get<T = unknown>(url: string, options?: ApiRequestOptions) {
    return this.send<T>('GET', url, options);
  }
  post<T = unknown>(url: string, options?: ApiRequestOptions) {
    return this.send<T>('POST', url, options);
  }
  put<T = unknown>(url: string, options?: ApiRequestOptions) {
    return this.send<T>('PUT', url, options);
  }
  patch<T = unknown>(url: string, options?: ApiRequestOptions) {
    return this.send<T>('PATCH', url, options);
  }
  delete<T = unknown>(url: string, options?: ApiRequestOptions) {
    return this.send<T>('DELETE', url, options);
  }

  private send<T>(method: string, url: string, options: ApiRequestOptions = {}): Promise<ApiResponse<T>> {
    return step(`API ${method} ${url}`, async () => {
      const response = await this.request.fetch(url, {
        method,
        data: options.data,
        params: options.params,
        headers: options.headers,
      });
      const text = await response.text();
      const status = response.status();
      const ok = options.expectStatus !== undefined ? status === options.expectStatus : response.ok();
      if (!ok) {
        const expected = options.expectStatus ?? '2xx';
        throw new Error(`${method} ${url} returned ${status} (expected ${expected}): ${text.slice(0, 500)}`);
      }
      return { status, headers: response.headers(), body: parseBody(text) as T };
    });
  }
}

function parseBody(text: string): unknown {
  if (!text) return undefined;
  try {
    return JSON.parse(text);
  } catch {
    return text;
  }
}
