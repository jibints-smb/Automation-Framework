/** Small helpers for unique test data (no extra dependencies). */

export function uniqueId(prefix = ''): string {
  return `${prefix}${Date.now().toString(36)}${Math.random().toString(36).slice(2, 6)}`;
}

export function uniqueEmail(domain = 'example.com'): string {
  return `qa.${uniqueId()}@${domain}`;
}

export function randomDigits(length: number): string {
  return Array.from({ length }, () => Math.floor(Math.random() * 10)).join('');
}
