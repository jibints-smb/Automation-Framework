import { expect, type Page } from '@playwright/test';
import type { WebField } from '@core/models/field.types';
import { step } from '@core/utils/step';
import { locateField } from './locator';

/**
 * Readable, auto-waiting assertions on model fields.
 * Each check is a named report step, e.g. `Verify "Error message" has text "..."`.
 */
export class WebAssertions {
  constructor(private readonly page: Page) {}

  async visible(field: WebField): Promise<void> {
    await step(`Verify "${field.label}" is visible`, () => expect(locateField(this.page, field)).toBeVisible());
  }

  async hidden(field: WebField): Promise<void> {
    await step(`Verify "${field.label}" is hidden`, () => expect(locateField(this.page, field)).toBeHidden());
  }

  async text(field: WebField, expected: string | RegExp): Promise<void> {
    await step(`Verify "${field.label}" has text "${expected}"`, () =>
      expect(locateField(this.page, field)).toHaveText(expected),
    );
  }

  async containsText(field: WebField, expected: string | RegExp): Promise<void> {
    await step(`Verify "${field.label}" contains "${expected}"`, () =>
      expect(locateField(this.page, field)).toContainText(expected),
    );
  }

  async value(field: WebField, expected: string | RegExp): Promise<void> {
    await step(`Verify "${field.label}" has value "${expected}"`, () =>
      expect(locateField(this.page, field)).toHaveValue(expected),
    );
  }

  async count(field: WebField, expected: number): Promise<void> {
    await step(`Verify ${expected} x "${field.label}"`, () =>
      expect(locateField(this.page, field)).toHaveCount(expected),
    );
  }

  async enabled(field: WebField, enabled = true): Promise<void> {
    await step(`Verify "${field.label}" is ${enabled ? 'enabled' : 'disabled'}`, () =>
      enabled
        ? expect(locateField(this.page, field)).toBeEnabled()
        : expect(locateField(this.page, field)).toBeDisabled(),
    );
  }

  async checked(field: WebField, checked = true): Promise<void> {
    await step(`Verify "${field.label}" is ${checked ? 'checked' : 'unchecked'}`, () =>
      expect(locateField(this.page, field)).toBeChecked({ checked }),
    );
  }

  async url(expected: string | RegExp): Promise<void> {
    await step(`Verify URL matches "${expected}"`, () => expect(this.page).toHaveURL(expected));
  }

  async title(expected: string | RegExp): Promise<void> {
    await step(`Verify page title "${expected}"`, () => expect(this.page).toHaveTitle(expected));
  }
}
